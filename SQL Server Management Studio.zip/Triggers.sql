
DROP TABLE EmployeeLogger_174778

CREATE TABLE EmployeeLogger_174778
(
	LogData varchar(20)
)

ALTER TABLE EMPLOYEES_174778
ADD Gender varchar(6)

insert into EMPLOYEES_174778 VALUES (70, 'ABCA',2356.78,3,'FEMALE')

SELECT * FROM EMPLOYEES_174778

CREATE TRIGGER TRG_EMPLOYEES_153743_InsertLog
ON EMPLOYEES_174778
FOR INSERT 
AS 
BEGIN
	DECLARE @Id int
	SELECT @Id = ID FROM inserted
	INSERT INTO EmployeeLogger_174778
	VALUES('New Employee with Id = '+Cast(@Id as nvarchar(5))+
	'is added at ' + cast(Getdate() as nvarchar(25)))
END

CREATE TRIGGER TRG_EMPLOYEES_174778_BEFORE_UPDATE
ON
EMPLOYEES_174778
INSTEAD OF UPDATE
AS 
BEGIN
	RAISERROR('Unauthorised UPDATE Blocked' , 16 , 1)
END

UPDATE	EMPLOYEES_174778 SET Marks = 1000 WHERE Id = 2

delete from EMPLOYEES_174778 where id = 4 or id =3

insert into EMPLOYEES_174778 VALUES (1, 'Sagar',101,NULL,'male')

