
CREATE VIEW vwGetAllDepartmentEmployees_174778

AS

SELECT EMPLOYEES_174778.Id, EMPLOYEES_174778.Name,DEPARTMENT_174778.DepartmentName
FROM EMPLOYEES_174778
INNER JOIN 
DEPARTMENT_174778 
ON EMPLOYEES_174778.DeptId 
=DEPARTMENT_174778.DepartmentId


----using view----

SELECT * FROM vwGetAllDepartmentEmployees_174778

SELECT * FROM vwGetAllDepartmentEmployees_174778 WHERE DepartmentName = 'HR'

SELECT * FROM EMPLOYEES_174778

----updatable thats why only read access is given ------
UPDATE vwGetAllDepartmentEmployees_174778 SET Name='xyz' WHERE Id=7

--DELETE FROM vwGetAllDepartmentEmployees_174778 WHERE Id=7-----
--can't delete thats why update is not used---


