---1.2----

use master 
go

select DB_NAME()
go

use Training 
go

sp_help
go

---Master---
use master 
go

select DB_NAME()
go

use Master 
go

sp_help
go


---NorthWind---
use Northwind 
go

select DB_NAME()
go

use Northwind 
go

sp_help
go


Select @@version
go

Select GETDATE()
go

sp_help Categories
go

sp_help Products
go

sp_help Orders
go

sp_help OrderDetail
go

sp_help Employees
go




---Training------
use Training 
go

select DB_NAME()
go

use Training 
go

sp_help
go


Select @@version
go

Select GETDATE()
go


sp_help Categories
go

sp_help Products
go

sp_help Orders
go

sp_help OrderDetail
go

sp_help Employees
go
----1.3---

---1---
CREATE TABLE Customer_174778
(
CustomerID int PRIMARY KEY NOT NULL,
CustomerName varchar(20) NOT NULL,
Address1 varchar(30),
address2 varchar(30),
ContactNo varchar(12) NOT NULL,
PostalCode varchar(10)
)

---2---

CREATE TABLE Employees_174778
(
EmployeeID int PRIMARY KEY NOT NULL,
Name nvarchar(255) NULL
)

---3---

CREATE TABLE Contractors_174778
(
ContractorId INT NOT NULL PRIMARY KEY,
Name NVARCHAR(255) NULL
);---4----USE Training;
CREATE TABLE dbo.TestRethrow_174778
(
ID INT PRIMARY KEY
)

---1---

--CREATING USER DEFINED DATATYPE----

CREATE TYPE Region_174778 from varchar(15);

CREATE DEFAULT Address AS 'NA'
go

EXEC sp_bindefault Address, 'Region_174778'ALTER TABLE Customer_174778
ADD Customer_Region  Region_174778;


select* from Customer_174778
