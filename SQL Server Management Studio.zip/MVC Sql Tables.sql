
CREATE TABLE tbl_User
(
ID int PRIMARY KEY IDENTITY(1,1) NOT NULL,
Name varchar(50),
PhoneNo varchar(20),
Address varchar(50),
Email varchar(50)
)

DROP TABLE tbl_User

CREATE DATABASE SagarPanigrahi_174778

alter table tbl_User
add Age int

select * from tbl_User

CREATE TABLE tbl_Car
(
carID int PRIMARY KEY IDENTITY(1,1) NOT NULL,
carName varchar(50),
carVariant varchar(50)
)


CREATE

SELECT * FROM EMPLOYEE_174778_LAB1

