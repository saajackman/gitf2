CREATE TABLE Car_174778
(
CarRegNo varchar(60) PRIMARY KEY NOT NULL,
CarType varchar(50)
)

drop table Car_174778

CREATE PROCEDURE Insert_CarDetails
@RegNo varchar(60),
@CarType varchar(60)
AS
BEGIN
	INSERT INTO Car_174778 VALUES(@RegNo , @CarType)
END

select * from Car_174778



CREATE PROCEDURE Search_CarDetails
@CarRegNo varchar(60)
AS
BEGIN
	SELECT * FROM Car_174778 WHERE CarRegNo=@CarRegNo
END


use SagarPanigrahi_174778
go

CREATE TABLE Yammer_174778
(
userID int PRIMARY KEY NOT NULL IDENTITY(1,1),
Name varchar(50),
Email varchar(50),
Password varchar(50),
PhoneNo varchar(12),
dob datetime,
gender varchar(2),
terms varchar(5)
)


DROP TABLE Yammer_174778

select * from Yammer_174778

CREATE PROCEDURE usp_SignUp_INSERT
@Name varchar(50),
@Email varchar(50),
@Password varchar(50),
@PhoneNo varchar(12),
@Dob datetime,
@gender varchar(2),
@terms varchar(5)
AS
BEGIN
	INSERT INTO Yammer_174778 VALUES(@Name,@Email,@Password,@PhoneNo,@Dob,@gender,@terms)
END




drop procedure usp_SignUp_INSERT

CREATE PROCEDURE usp_ValidateLogin_174778
@Email varchar(50),
@Password varchar(50)
AS
BEGIN
	SELECT * FROM Yammer_174778 WHERE EMAIL=@EMAIL AND Password=@Password
END

