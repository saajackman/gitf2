
create table Product_174778
(
productID int PRIMARY KEY,
productName varchar (20),
productPrice varchar(20)
)
insert into Product_174778 values (101,'HP NoteBook-778' ,'32000')

select * from Product_174778



