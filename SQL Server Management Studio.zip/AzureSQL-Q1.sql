
use  SQL-DB-Q1
go 
create table Car_Models
(
Id int PRIMARY KEY , 
Model nvarchar(20),
Company nvarchar(10),
Released nvarchar(10),
Country nvarchar(20)
)
select * from Car_Models