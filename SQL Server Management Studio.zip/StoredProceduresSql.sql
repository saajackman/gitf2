
-----CREATING STORED PROCEDURE-----

CREATE PROCEDURE AddSoldProduct_174778
@ProductID int , 
@UnitPrice int,
@QtySold int
AS 
BEGIN 
	INSERT INTO PRODUCTS_SALES_174778  VALUES (@ProductID ,@UnitPrice ,@QtySold)
END

---EXECUTE STORED PROCEDURE---

EXECUTE AddSoldProduct_174778 2,300,20
----OR----
EXEC AddSoldProduct_174778 1,100,10

SELECT *  FROM PRODUCTS_SALES_174778


CREATE PROCEDURE UpdateProducts_174778
@pID int , 
@pName VARCHAR(60),
@pDescription VARCHAR(260)
AS 
BEGIN 
	UPDATE PRODUCTS_174778 SET  Name = @pName ,Description = @pDescription WHERE  Id = @pID 
END

EXEC UpdateProducts_174778 2, 'TV','LCD' 
EXEC UpdateProducts_174778 2, 'Laptop','15.9 inch HP Laptop' 

SELECT *  FROM PRODUCTS_174778

---search employee names under manager id =1 -----

CREATE PROCEDURE SEARCHEmployee_174778
@Id int 
AS 
BEGIN 
SELECT Name FROM EMP_MANAGERS_174778 WHERE ManagerId =@Id
END

EXEC SEARCHEmployee_174778 1

---STORED PROCEDURE WITH RETURN -----

SELECT * FROM EMP_MANAGERS_174778

CREATE PROCEDURE GetEmployeeCount_174778
@ManagerId int,
@ReportingEmployeeCount int OUTPUT
AS
BEGIN

	SELECT COUNT(EmployeeID) FROM EMP_MANAGERS_174778 WHERE ManagerId = @ManagerId
END

DECLARE @EmployeeCount int
EXECUTE GetEmployeeCount_174778 1, @EmployeeCount
PRINT @EmployeeCount

SELECT * FROM Customer


CREATE PROCEDURE GetEmployeeCount_174778
@ManagerId int,
@ReportingEmployeeCount int OUTPUT
AS
BEGIN

	SELECT COUNT(EmployeeID) FROM EMP_MANAGERS_174778 WHERE ManagerId = @ManagerId
END

DECLARE @EmployeeCount int
EXECUTE GetEmployeeCount_174778 1, @EmployeeCount
PRINT @EmployeeCount




select * from Customer



CREATE TABLE CUSTOMER_174778
(
cID INT PRIMARY KEY NOT NULL,
fName VARCHAR(60),
lName VARCHAR(60),
Address varchar(60),
City varchar(60),
PhoneNo varchar(20)
)

CREATE TABLE STUDENTS_174778
(
	studentId int PRIMARY KEY NOT NULL,
	studentName varchar(60),
	Qualification varchar(60) CHECK (Qualification = 'BE' OR Qualification = 'ME'),
	city varchar(20) CHECK  (City = 'Mumbai' OR City = 'Mumbai' OR City = 'Mumbai' OR City = 'Mumbai')
)


DROP TABLE STUDENTS_174778

SELECT * FROM STUDENTS_174778

CREATE TABLE STUDENT_MARKS_174778
(
marksID int primary key ,
studentID int FOREIGN KEY REFERENCES STUDENTS_174778,
marks1 INT ,
marks2 INT ,
marks3 INT 
)

CREATE PROCEDURE usp_StudentInsert
@StudentID INT , 
@StudentName varchar(60) ,
@qual varchar(60),
@city varchar(20)
AS
BEGIN
INSERT INTO STUDENTS_174778 VALUES (@StudentID , @StudentName ,@qual , @city)
END

EXEC usp_StudentInsert 102,'Sagar','BE','Mumbai'

CREATE PROCEDURE usp_DeleteStudentData
@StudentID int
AS
BEGIN
 DELETE FROM STUDENTS_174778 WHERE studentId = @StudentID
END


CREATE PROCEDURE usp_STUDENT_SEARCH
@StudentId INT
AS 
BEGIN
 SELECT * FROM STUDENTS_174778 WHERE studentID = @StudentId
END

CREATE PROCEDURE usp_Student_DELETE_Data
@StudentName varchar(60)
AS 
BEGIN
 DELETE FROM STUDENTS_174778 WHERE studentName = @StudentName
END

exec usp_STUDENT_DELETE 102

CREATE PROCEDURE usp_StudentALL_174778
AS 
BEGIN
SELECT * FROM STUDENTS_174778
END