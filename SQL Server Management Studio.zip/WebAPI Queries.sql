CREATE TABLE tbl_Student_174778
(
ID int PRIMARY KEY NOT NULL Identity(1,1),
Name varchar(20),
Class varchar(20),
div varchar(2)
)
drop table tbl_Student_174778
INSERT INTO tbl_Student_174778 VALUES('Sagar','First','A')
INSERT INTO tbl_Student_174778 VALUES('Panigrahi','Second','B')
INSERT INTO tbl_Student_174778 VALUES('Jackman','Third','C')

select * from tbl_Student_174778