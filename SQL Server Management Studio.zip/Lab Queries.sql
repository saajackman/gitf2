CREATE TABLE EMPLOYEE_174778_LAB1
(
empNo int IDENTITY (1,1) PRIMARY KEY NOT NULL,
empName varchar(50) NOT NULL,
empSal numeric(10,2) CHECK (empsal >=25000),
empType varchar(1) CHECK (empType in('C', 'P'))
)

DROP TABLE EMPLOYEE_174778_LAB1

CREATE PROCEDURE GetEmployeeByID_174778
@eNo int
AS
BEGIN
	SELECT * FROM EMPLOYEE_174778_LAB1 WHERE empNo = @eNo
END

select * from EMPLOYEE_174778_LAB1

CREATE PROCEDURE DELETE_EMPLOYEE_174778
@eNo int
AS 
BEGIN
	DELETE FROM EMPLOYEE_174778_LAB1 WHERE empNo=@eNo
END

DROP PROCEDURE DELETE_EMPLOYEE_174778

CREATE PROCEDURE UPDATE_EMPLOYEE_174778
@eNo int,
@ename varchar(50),
@esal numeric(10,2) ,
@etype varchar(1)
AS
BEGIN
	UPDATE  EMPLOYEE_174778_LAB1 SET empName=@ename,empSal=@esal,empType=@etype WHERE empNo=@eNo
END

UPDATE  EMPLOYEE_174778_LAB1 SET empName='Sagar' WHERE empNo=103
DROP PROCEDURE DELETE_EMPLOYEE_174778

create table ApplicationUsers_174778
(
userid varchar(10) primary key,
username varchar(30) not null,
city varchar(30) not null,
password varchar(30) check(len(password) >5)
)

drop table usp_ApplicationUsers_174778
insert into ApplicationUsers_174778 values(1,'sagar','Muumbai','sagar@123')

select * from ApplicationUsers_174778

create table customer_174778_Lab4
(
customerid int identity primary key,
customername varchar(50),
city varchar(30),
creditlimit numeric(10,2)
)

CREATE TABLE Supplier_174778
(
 SupplierId int primary key,
  Suppliername varchar(50), 
  City varchar(50),
   ContactNo INT,
CreditBalance INT
)

INSERT INTO Supplier_174778 VALUES (103,'SAGAR','DELHI','554456767',30000)

	CREATE TABLE CATEGORIES_174778
	(
	  categoryid  INT IDENTITY PRIMARY KEY , 
	  categoryname varchar(50)
	)

	CREATE TABLE PRODUCTS_174778
	(
	  productid  INT IDENTITY PRIMARY KEY , 
	  productname varchar(50),
	  categoryid INT 
	)

	drop table PRODUCTS_174778

CREATE TABLE PRODUCTS_174778
(
  productid INT  PRIMARY KEY   NOT NULL ,
  productname  varchar(50) NULL ,
   categoryid INT 

  CONSTRAINT c
    FOREIGN KEY (categoryid)
    REFERENCES CATEGORIES_174778 (categoryid)
    ON DELETE CASCADE
 
)

	
	SELECT * FROM CATEGORIES_174778
	SELECT * FROM PRODUCTS_174778
	UPDATE PRODUCTS_174778 SET categoryid=2  where productname = 'LENOVO' --and  productname = 'GODREJ' and productname = 'SAMSUNG'
	

	ALTER TABLE PRODUCTS_174778
	ADD CatID INT

	ALTER TABLE PRODUCTS_174778
	ADD CONSTRAINT FK_CatecatId_ProdprodId_174778 FOREIGN KEY (CatID) REFERENCES CATEGORIES_174778 

	INSERT INTO CATEGORIES_174778 VALUES('PC')
	INSERT INTO PRODUCTS_174778 VALUES(6,'HITACHI',1)

	CREATE DATABASE MusicStore_174778

	CREATE TABLE Album_174778
	(
		AlbumID INT PRIMARY KEY NOT NULL,
		Name varchar(50),
		Genre varchar(50),
		Year datetime,
		Price numeric(10,2)
	)
	 DROP TABLE Album_174778
		insert into Album_174778 VALUES(2,'WORLDDOMINION','ROCK',1989/05/12,90033790.89)

		SELECT * FROM Album_174778

 CREATE DATABASE TRAINING_MODEL_174778

 DROP TABLE STUDENT_MASTER

	CREATE TABLE STAFF_MASTER_174778
	(
		Staff_Code int primary key NOT NULL,
		Staff_Name varchar(50) ,
		Des_Code int,
		Dept_Code int ,
		Staff_dob datetime,
		Hiredate datetime,
		Mgr_code int,
		Salary decimal(10,2),
		Address varchar(50) 
	)

	CREATE TABLE STUDENT_MASTER
	(
		Stud_Code int PRIMARY KEY NOT NULL,
		Stud_Name varchar(50),
		Dept_Code int ,
		Stud_Dob datetime,
		Address varchar(50) 
	)

	select * from STUDENT_MASTER

drop table BMS_174778

CREATE TABLE BMS_174778
(
 bookID int primary key not null,
 bookName varchar(50),
 isbn varchar(50),
 price float,
 publisher varchar(50),
 noOfPages int ,
 language varchar(50),
 summary varchar(120)
)

INSERT INTO BMS_174778 VALUES (1 ,'Macbeth' ,'101',232,'Arient Publishers',200,'English','Shakespear')
drop procedure usp_INSERT_174778

CREATE PROCEDURE usp_INSERT_174778
 @bID int,
 @bookName varchar(50),
 @isbn varchar(50),
 @price float,
 @publisher varchar(50),
 @noOfPages int ,
 @language varchar(50),
 @summary varchar(120)
 AS
 BEGIN
	INSERT INTO BMS_174778 VALUES (@bID ,@bookName, @isbn, @price,@publisher, @noOfPages,@language,@summary)
END


SELECT * FROM BMS_174778
drop procedure usp_UPDATE_BMS_174778
usp_UPDATE_NEW_BMS_174778

CREATE PROCEDURE usp_UPDATE_BMS_174778
 @bID int,
 @bookName varchar(50),
 @isbn varchar(50),
 @price float,
 @publisher varchar(50),
 @noOfPages int ,
 @language varchar(50),
 @summary varchar(120)

 AS
 BEGIN
	UPDATE BMS_174778 SET bookName=@bookName , isbn=@isbn , price=@price , 
	publisher=@publisher , noOfPages=@noOfPages , language=@language , summary=@summary  WHERE bookID=@bID
END

EXEC usp_UPDATE_NEW_BMS_174778 'Macbeth' ,'101',232,'Arice Publishers',200,'English','Shakespear' ,101


CREATE PROCEDURE usp_BMS_Displayall_174778
AS
BEGIN
	SELECT * FROM BMS_174778
END

drop procedure usp_BMS_DisplayOneBook_173778

CREATE PROCEDURE usp_BMS_DisplayOneBook_174778
@bID INT
AS
BEGIN
	SELECT * FROM BMS_174778 WHERE bookID=@bID
END

SELECT * FROM BMS_174778 WHERE bookID=0
EXECUTE usp_BMS_DisplayOneBook_174778 1
CREATE PROCEDURE usp_BMS_DeleteBook_173778
@bID INT
AS
BEGIN
	DELETE FROM BMS_174778 WHERE bookID=@bID
END

select * from student_master 


create database EmployeeModel_174778


create table ModelEmp_174778
ID
Name
DOB
DOJ
Designation
Salary

select * from Tbl_Student_174778
drop table 

